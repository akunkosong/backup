<?php 
	try {
			$pdo = new PDO('mysql:host=localhost;dbname=db_spp;','root','');
		} catch (PDOException $e) {
			echo "Kesalahan Fatal ".$e->getmessage();
		}	
 ?>