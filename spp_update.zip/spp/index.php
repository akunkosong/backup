<?php 
	
	include 'view/header.php';

	$page = (isset($_GET['page']))?$_GET['page']:'dashboard';
	switch ($page) {
		case 'dashboard':include'view/main.php';break;
		case 'tambah-siswa':include'view/tambah-siswa.php';break;
		case 'tambah-biaya':include'view/tambah-biaya.php';break;
		case 'bayar':include'view/bayar.php';break;
		case 'rekap':include'view/rekap.php';break;
		case 'setting':include'view/setting.php';break;
		
		case 'dashboard':
		default:include'view/main.php';break;
	}

	include 'view/footer.php';

 ?>