<?php 
	require_once('../config/config.php');
	if(!empty($_POST['simpan'])){
		$nama = htmlspecialchars(strtolower($_POST['nama']));
		$kelas = htmlspecialchars(strtolower($_POST['kelas']));
		$rombel = htmlspecialchars(strtolower($_POST['rombel']));

		//check data siswa sudah ada dalam database atau belum
		try {
			$sqlCheck = "SELECT * FROM siswa WHERE nama = ?";
			$sSis = $pdo->prepare($sqlCheck);
			$sSis->bindparam(1, $nama, PDO::PARAM_STR);
			$sSis->execute();
			$csS = $sSis->rowcount();
			if($csS > 0){
				echo '<script>alert("Data dengan nama tersebut sudah ada, silahkan berikan tanda hitung A, B, C atau nama kelas contoh: Hasan A");</script>';
			}else{
				try {
					$sqlSimpan = "INSERT INTO siswa(nama, kelas, rombel) VALUES(?,?,?)";
					$simpan = $pdo->prepare($sqlSimpan);
					$simpan->bindparam(1, $nama, PDO::PARAM_STR);
					$simpan->bindparam(2, $kelas, PDO::PARAM_STR);
					$simpan->bindparam(3, $rombel, PDO::PARAM_STR);
					$simpan->execute();
					if($simpan){
						echo "<script>alert('Data siswa {$nama} {$kelas} {$rombel} berhasil disimpan!');document.location.href='tambah-siswa';</script>";
					}else{
						echo "<script>alert('Data siswa {$nama} {$kelas} {$rombel} gagal disimpan!');</script>";
						return false;
					}
				} catch (PDOException $e) {
					echo "Kesalahan Fatal ".$e->getmessage();
				}
			}
		} catch (PDOException $e) {
			echo "Kesalahan Fatal ".$e->getmessage();
		}
	}
 ?>