<?php 
	
	require_once('../config/config.php');
	if(!empty($_POST['id'])){

		$sql = "SELECT * FROM biaya WHERE id_kelas = '".$_POST['id']."'";
		$pilih = $pdo->prepare($sql);
		$pilih->execute();
		$cp = $pilih->rowcount();
		if($cp > 0){
			foreach($pilih as $bayar){?>
				<option value="<?=$bayar['id']?>"><?=$bayar['namabiaya']?></option>
		<?php	}
		}else{
			echo 'Nama Biaya tidak ditemukan!';
		}
	}

 ?>