<?php 
	require_once('../config/config.php');
	if(!empty($_POST['simpan'])){
		$ta = htmlspecialchars(strtolower($_POST['ta']));
		

		//check data siswa sudah ada dalam database atau belum
		try {
			$sqlCheck = "SELECT * FROM ta WHERE ta = ?";
			$sSis = $pdo->prepare($sqlCheck);
			$sSis->bindparam(1, $ta, PDO::PARAM_STR);
			$sSis->execute();
			$csS = $sSis->rowcount();
			if($csS > 0){
				echo '<script>alert("Data Tahun Ajaran {$ta} sudah ada!");</script>';
			}else{
				try {
					$sqlSimpan = "INSERT INTO ta(ta) VALUES(?)";
					$simpan = $pdo->prepare($sqlSimpan);
					$simpan->bindparam(1, $ta, PDO::PARAM_STR);
					$simpan->execute();
					if($simpan){
						echo "<script>alert('Data Tahun Ajaran {$ta} berhasil disimpan!');document.location.href='setting';</script>";
					}else{
						echo "<script>alert('Data Tahun Ajaran {$ta} gagal disimpan!');</script>";
						return false;
					}
				} catch (PDOException $e) {
					echo "Kesalahan Fatal ".$e->getmessage();
				}
			}
		} catch (PDOException $e) {
			echo "Kesalahan Fatal ".$e->getmessage();
		}
	}
 ?>