<?php 
	require_once('../config/config.php');
	if(!empty($_POST['simpan'])){
		$kls = htmlspecialchars(strtolower($_POST['kelas']));
		$prn = htmlspecialchars(strtolower($_POST['parent']));
		
		try {
					$sqlSimpan = "INSERT INTO kelas(kelas, parent) VALUES(?,?)";
					$simpan = $pdo->prepare($sqlSimpan);
					$simpan->bindparam(1, $kls, PDO::PARAM_STR);
					$simpan->bindparam(2, $prn, PDO::PARAM_STR);
					$simpan->execute();
					if($simpan){
						echo "<script>alert('Data Kelas {$kls} berhasil disimpan!');document.location.href='setting';</script>";
					}else{
						echo "<script>alert('Data Kelas {$kls} gagal disimpan!');document.location.href='setting';</script>";
						return false;
					}
				} catch (PDOException $e) {
					echo "Kesalahan Fatal ".$e->getmessage();
				}
	}
 ?>