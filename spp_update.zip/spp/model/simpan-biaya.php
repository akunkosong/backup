<?php 
	require_once('../config/config.php');
	if(!empty($_POST['simpan'])){
		$kls = htmlspecialchars(strtolower($_POST['kelas']));
		$ta = htmlspecialchars(strtolower($_POST['ta']));
		$nama = htmlspecialchars(strtolower($_POST['namabiaya']));
		$total = htmlspecialchars(strtolower($_POST['totalbiaya']));

		try {
			$sqlSimpan = "INSERT INTO biaya(id_kelas, id_ta, namabiaya, totalbiaya) VALUES(?,?,?,?)";
			$simpan = $pdo->prepare($sqlSimpan);
			$simpan->bindparam(1, $kls, PDO::PARAM_STR);
			$simpan->bindparam(2, $ta, PDO::PARAM_STR);
			$simpan->bindparam(3, $nama, PDO::PARAM_STR);
			$simpan->bindparam(4, $total, PDO::PARAM_STR);
			$simpan->execute();
			if($simpan){
				echo "<script>alert('Data pembiayaan {$kls} {$ta} {$nama} {$total} berhasil disimpan!');document.location.href='tambah-biaya';</script>";
			}else{
				echo "<script>alert('Data pembiayaan {$klss} {$ta} {$nama} {$total} gagal disimpan!');</script>";
				return false;
			}
		} catch (PDOException $e) {
			echo "Kesalahan Fatal ".$e->getmessage();
		}
	}
 ?>