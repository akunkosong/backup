<?php 
	
	require_once('../config/config.php');
	if(!empty($_POST['id'])){

		$sql = "SELECT * FROM siswa WHERE kelas = '".$_POST['id']."'";
		$pilih = $pdo->prepare($sql);
		$pilih->execute();
		$cp = $pilih->rowcount();
		if($cp > 0){
			foreach($pilih as $siswa){?>
				<option value="<?=$siswa['id']?>"><?=$siswa['nama']?> </option>
		<?php	}
		}else{
			echo 'Kelas tidak ditemukan!';
		}
	}

 ?>