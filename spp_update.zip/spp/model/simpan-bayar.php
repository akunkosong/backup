<?php 
	require_once('../config/config.php');
	if(!empty($_POST['simpan'])){
		$nama = htmlspecialchars(strtolower($_POST['namasiswabayar']));
		$jenis = htmlspecialchars(strtolower($_POST['jenisbiayabayar']));
		$jta = htmlspecialchars(strtolower($_POST['jenista']));
		$bln = htmlspecialchars(strtolower($_POST['bulan']));
		$total = htmlspecialchars(strtolower($_POST['totalbiaya']));

		//check data siswa sudah ada dalam database atau belum
		try {
			$sqlCheck = "SELECT * FROM bayar WHERE bulan = ? AND ta = ?";
			$sSis = $pdo->prepare($sqlCheck);
			$sSis->bindparam(1, $bln, PDO::PARAM_STR);
			$sSis->bindparam(2, $jta, PDO::PARAM_STR);
			$sSis->execute();
			$csS = $sSis->rowcount();
			if($csS > 0){
				echo '<script>alert("Data dengan nama pembiayaan Bulan {$bln} Tahun Ajaran {$jta} sudah ada, silahkan gunakan nama yang lain!");</script>';
			}else{
				try {
					$sqlSimpan = "INSERT INTO bayar(id_siswa, id_bayar, bulan, ta, jumlah) VALUES(?,?,?,?,?)";
					$simpan = $pdo->prepare($sqlSimpan);
					$simpan->bindparam(1, $nama, PDO::PARAM_STR);
					$simpan->bindparam(2, $jenis, PDO::PARAM_STR);
					$simpan->bindparam(3, $bln, PDO::PARAM_STR);
					$simpan->bindparam(4, $jta, PDO::PARAM_STR);
					$simpan->bindparam(5, $total, PDO::PARAM_STR);
					$simpan->execute();
					if($simpan){
					  var_dump($simpan);
						echo "<script>alert('Data pembiayaan {$nama} {$total} berhasil disimpan!');document.location.href='bayar';</script>";
					}else{
						echo "<script>alert('Data pembiayaan {$nama} {$total} gagal disimpan!');document.location.href='bayar';</script>";
						return false;
					}
				} catch (PDOException $e) {
					echo "Kesalahan Fatal ".$e->getmessage();
				}
			}
		} catch (PDOException $e) {
			echo "Kesalahan Fatal ".$e->getmessage();
		}
	}
 ?>