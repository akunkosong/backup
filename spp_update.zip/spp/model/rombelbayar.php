<?php 
	
	require_once('../config/config.php');
	if(!empty($_POST['id'])){

		$sql = "SELECT * FROM siswa WHERE id = '".$_POST['id']."'";
		$pilih = $pdo->prepare($sql);
		$pilih->execute();
		$cp = $pilih->rowcount();
		if($cp > 0){
			foreach($pilih as $siswa){
			  $kid = $siswa['rombel'];
			  $dik = $pdo->prepare("SELECT * FROM kelas WHERE id = '$kid'");
			  $dik->execute();
			  $cdik = $dik->rowcount();
			  if($cdik > 0){
			    foreach($dik as $kids){?>
				<option value="<?=$kids['id']?>"><?=$kids['kelas']?> </option>
		<?php	} } }
		}else{
			echo 'Kelas tidak ditemukan!';
		}
	}

 ?>