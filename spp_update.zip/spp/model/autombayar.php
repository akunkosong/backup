<?php 
	
	require_once('../config/config.php');
	if(!empty($_POST['id'])){

		$sql = "SELECT * FROM biaya WHERE id = '".$_POST['id']."' limit 1";
		$pilih = $pdo->prepare($sql);
		$pilih->execute();
		$cp = $pilih->rowcount();
		if($cp > 0){
			foreach($pilih as $siswa){
				echo json_encode($siswa);
			}
		}else{
			echo 'data tidak ditemukan!';
		}
	}

 ?>