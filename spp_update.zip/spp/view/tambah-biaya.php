<div style="padding:5px;text-align: right;">
	<button id="tgl" class="btn btn-warning" onclick="toggle();">+ Biaya</button>
</div>
<form method="post" id="tSiswa" action="<?=htmlspecialchars('simpan-biaya')?>">
	<div class="fg">
		<select name="kelas" class="fc" required style="text-transform:uppercase;">
			<option value="0">- Pilih Kelas -</option>
	     		<?php
			  require_once('config/config.php');
			  $kel = "SELECT * FROM kelas WHERE parent = 0";
			  $las = $pdo->prepare($kel);
			  $las->execute();
			  $clas = $las->rowcount();
			  if($clas > 0){
			    foreach($las as $kelas){?>
			<option value="<?=$kelas['id']?>"><?=$kelas['kelas']?></option>
			<?php    }
			  }
			?> 
		</select>
		</div>
	<div class="fg"> 
		<select name="ta" class="fc" required>
			<option value="0">- Pilih Tahun Ajaran-</option>
	     		<?php
			  require_once('config/config.php');
			  $kel = "SELECT * FROM ta WHERE status = 0";
			  $las = $pdo->prepare($kel);
			  $las->execute();
			  $clas = $las->rowcount();
			  if($clas > 0){
			    foreach($las as $kelas){?>
			<option value="<?=$kelas['id']?>"><?=$kelas['ta']?></option>
			<?php    }
			  }
			?> 
		</select>
	</div>
	<div class="fg">
		<input type="text" name="namabiaya" class="fc" placeholder="Nama Pembiayaan" required>
	</div>
	<div class="fg">
		<input type="text" name="totalbiaya" class="fc" placeholder="Total Biaya" required>
	</div>
	<div class="fg">
		<input type="submit" name="simpan" class="btn btn-success" value="Simpan">
	</div>
</form>
<br>
<div style="overflow-x:auto;">
  <table>
	<thead>
		<tr>
			<td>No</td>
			<td>Kelas</td>
			<td>Tahun Ajaran</td>
			<td>Nama Biaya</td>
			<td>Total</td>
		</tr>
	</thead>
	<tbody>
		<?php
			$no = 1; 
			require_once('config/config.php');
			$sql = "SELECT * FROM biaya";
			$tar = $pdo->prepare($sql);
			$tar->execute();
			$ct = $tar->rowcount();
			if($ct > 0){
				foreach($tar as $ik){
				  $idk = $ik['id_kelas'];
				  $kel = $pdo->prepare("SELECT * FROM kelas where id = '$idk'");
				  $kel->execute();
				  $ckel = $kel->rowcount();
				  if($ckel > 0){
				    foreach ($kel as $las){
				      $idt = $ik['id_ta'];
				      $tah = $pdo->prepare("SELECT * FROM ta WHERE id = '$idt'");
				      $tah->execute();
				      $ctah = $tah->rowcount();
				      if($ctah > 0){
				        foreach($tah as $un){
				?>

		<tr>
			<td><?=$no++;?></td>
			<td style="text-transform: capitalize;"><?=$las['kelas']?></td>
			<td style="text-transform: capitalize;"><?=$un['ta']?></td>
			<td style="text-transform: capitalize;"><?=$ik['namabiaya']?></td>
			<td style="text-transform: uppercase;">Rp. <?=number_format($ik['totalbiaya'])?></td>
		</tr>
		<?php		
			} } } } }
			}
		 ?>
	</tbody>
</table>
</div>
<script type="text/javascript">
	function toggle()
	{
		var a = document.getElementById('tSiswa');
		if(a.style.display==='none'){
			a.style.display='block';

		}else{
			a.style.display='none';
		}
	}
</script>