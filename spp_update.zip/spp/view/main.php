<h1>Assalamu'alaikum Warohmatullohi Wabarokatuh</h1>
<p style="text-align:justify;">
	temenngoding.com mengucapkan terima kasih banyak bagi teman - teman yang udah berpartisipasi dan memberikan sumbangan baik melalui rekening atau ovo, mudah - mudahan sumbangan teman - teman semua menjadi berkah dan mendapatkan balasan yang setimpal, semoga apa yang sudah didapat dari saya memiliki berkah. <br>

	Bagi teman - teman yang ingin ikut serta memberikan donasi silahkan ovo ke 0813 1526 9591. 

	<br>
	<br>
	Terima Kasih, <br>
	<pre>www.temenngoding.com</pre>
</pre>
