<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="description" content="Sumbangan Pemeliharaan Pendidikan">
	<meta name="keyword" content="Sumbangan Pendidikan, Pendidikan, Sekolah Menengah Pertama, Sekolah Menengah Atas, Sekolah Menengah Kejuruan, SMA, SMK, SMP, SD">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>.:: Management Administrasi Tata Usaha ::.</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h1>Management Administrasi Tata Usaha</h1>
		<p>Sumbangan Pembinaan Pendidikan (SPP)</p>
	</div>
	<div class="navbar">
		<a href="Setting">Konfigurasi</a>
		<a href="tambah-siswa">Tambah Siswa</a>
		<a href="tambah-biaya">Tambah Pembiayaan</a>
		<a href="bayar">Pembayaran</a>
		<a href="rekap">Rekap Pembayaran</a>
	</div>
	<div class="row">
		<div class="sidebar">
			<strong>Total Uang Masuk</strong>
			<div class="total">
			  <?php
			    require_once('config/config.php');
			    $mas = $pdo->prepare("SELECT sum(jumlah) as income FROM bayar");
			    $mas->execute();
			    $cmas = $mas->rowcount();
			    if($cmas > 0){
			      foreach ($mas as $suk){
			    ?>
				<h2>Rp. <?=number_format($suk['income'])?></h2>
			      
			    <?php }
			    }
			  
			  ?>
			</div>
			<br>
			<strong>Total Tunggakan Siswa</strong>
			<div class="total">
				<h2>Rp. 12.000.000</h2>
			</div>
			<br>
			<strong>Total Disetorkan</strong>
			<div class="total">
				<h2>Rp. 125.000.000</h2>
			</div>
		</div>
		<div class="main">