<div style="padding:5px;text-align: right;">
	<button id="tgl" class="btn btn-warning" onclick="toggle();">+ Bayar</button>
</div>
<form method="post" id="tSiswa" action="<?=htmlspecialchars('simpan-bayar')?>">
	<div class="fg">
		<select name="kelasbayar" id="kelasbayar" class="fc" required style="text-transform:uppercase; ">
			<option>- Pilih Kelas -</option>
			Siswa -</option>
			<?php
				require_once('config/config.php');
				$sis = "SELECT * FROM kelas where parent = 0";
				$wa = $pdo->prepare($sis);
				$wa->execute();
				$c = $wa->rowcount();
				if($c > 0){
					foreach($wa as $data){?>
						<option value="<?=$data["id"]?>"><?=$data["kelas"]?></option>
				<?php	}
				}
			 ?> 
		</select>
		</div>
		<div class="fg">
		<select name="namasiswabayar" class="fc" id="namasiswabayar" required>
			<option value="">- Pilih 
		</select>
	</div>
	<div class="fg">
		<select name="rombelbayar" class="fc" id="rombelbayar" required style="text-transform: uppercase;">
			<option value="0">- Kelas -</option>
		</select>
	</div>
	<div class="fg">
		<select name="jenisbiayabayar" class="fc" required id="jenisbiayabayar">
			<option value="0">- Jenis Bayar -</option>
		</select>
	</div>
	<div class="fg">
		<select name="jenista" class="fc" required id="jenista">
			<option value="">- Pilih Tahun Ajaran -</option>
			<?php 
			  $ta = "SELECT * FROM ta WHERE status = 0";
			  $tsh = $pdo->prepare($ta);
			  $tsh->execute();
			  $cta = $tsh->rowcount();
			  if($cta > 0){
			    foreach($tsh as $tahun){?>
			      <option value="<?=$tahun['id'];?>"><?=$tahun['ta']?></option>
			  <?php  }
			  }
			?>
		</select>
	</div>
	<div class="fg">
		<select name="bulan" class="fc" required>
			<option value="">- Bulan -</option>
			<?php
			  $bu = $pdo->prepare("SELECT * FROM bulan");
			  $bu->execute();
			  $cbu = $bu->rowcount();
			  if($cbu > 0){
			    foreach($bu as $lan){?>
			      <option value="<?=$lan['id']?>"><?=$lan['bulan'];?></option>
			  <?php  }
			  }
			?>
		</select>
	</div>
	<div class="fg">
		<input type="text" name="totalbiaya" id="totalbiaya" class="fc" placeholder="Total Biaya" required>
	</div>
	<div class="fg">
		<input type="submit" name="simpan" class="btn btn-success" value="Bayar">
	</div>
</form>
<br>
<div style="overflow-X:scroll;">
  <table>
	<thead>
		<tr>
			<td>No</td>
			<td>Nama Siswa</td>
			<td>Jenis Bayar</td>
			<td>Total</td>
		</tr>
	</thead>
	<tbody>
		<?php
			$no = 1; 
			require_once('config/config.php');
			$sql = "SELECT * FROM bayar";
			$tar = $pdo->prepare($sql);
			$tar->execute();
			$ct = $tar->rowcount();
			if($ct > 0){
				foreach($tar as $ik){
				  $siswaID = $ik['id_siswa'];
				  $tarsis = $pdo->prepare("SELECT * FROM siswa WHERE id = '$siswaID'");
				  $tarsis->execute();
				  $ctars = $tarsis->rowcount();
				  if($ctars > 0){
				    foreach ($tarsis as $sistar){
				      $jID = $ik['id_bayar'];
				      $bayid = $pdo->prepare("SELECT * FROM biaya where id = '$jID'");
				      $bayid->execute();
				      $cbay = $bayid->rowcount();
				      if($cbay > 0){
				        foreach ($bayid as $diyab){
				          $bulid = $ik['bulan'];
				          $bul = $pdo->prepare("SELECT * FROM bulan WHERE id = '$bulid'");
				          $bul->execute();
				          $cbl = $bul->rowcount();
				          if($cbl > 0){
				            foreach ($bul as $lan){
				?>

		<tr>
			<td><?=$no++;?></td>
			<td style="text-transform: capitalize;"><?=$sistar['nama']?></td>
			<td style="text-transform: capitalize;"><?=$diyab['namabiaya']?> Bulan <?=$lan['bulan'];?></td>
			<td style="text-transform: uppercase;">Rp. <?=number_format($ik['jumlah'])?></td>
		</tr>
		<?php } } } } } }
			}
			$s = "SELECT sum(jumlah) as jml FROM bayar";
			$st = $pdo->prepare($s);
			$st->execute();
			while($as = $st->fetch(PDO::FETCH_ASSOC)){
		?>
		<tr style="font-weight: bold;">
			<td colspan="3">Jumlah</td>
			<td>Rp. 
				<?=number_format($as['jml']);?>
			</td>
		</tr>
		<?php		
			}
			}
		 ?>
	</tbody>
</table>
</div>
