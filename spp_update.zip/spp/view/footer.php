
			
		</div>
	</div>
	<div class="footer">
		<h4>www.sekolahku.com</h4>
		<p>Jl. Raya Makam Keramat Solear Kp. Sukamanah Solear Tangerang</p>
	</div>
	<script type="text/javascript" src="jquery-1.10.2.js"></script>
	<script type="text/javascript">
		//panggil auto select siswa dengan kelas
		$('#namasiswa').on('change', function(){
			var a = $(this).val();
			if(a != ''){
				$.ajax({
					url:'er87cad',
					type:'post',
					// dataType:'JSON',
					data:{id : a},
					success:function(res){
						$('#kelas').html(res);
					}
				})
			}
		})
		
		//panggil auto jumlah bayar
		$('#jenisbiayabayar').on('change',function(){
			var c = $(this).val();
			if(c != ''){
				$.ajax({
					url:'ac8adc0a',
					type:'post',
					dataType:'JSON',
					data:{id: c},
					success:function(res){
						$('input#totalbiaya').val(res.totalbiaya);
					}
				})
			}
		})
		function toggle()
		{
			var a = document.getElementById('tSiswa');
			if(a.style.display==='none'){
				a.style.display='block';

			}else{
				a.style.display='none';
			}
		}
		//setting Tahun Ajaran
		$('.fg').on('click','#tta', function(){
			$('#fTa').toggle('slow');
		})
		//setting kelas
		$('.fg').on('click','#tkl',function(){
		  $('#fkls').toggle('slow');
		})
		//autoselect kelas siswa 
		$('#kelas').on('change', function(){
			var d = $(this).val();
			if(d != ''){
				$.ajax({
					url:'tng62ye8',
					type:'post',
					// dataType:'JSON',
					data:{id : d},
					success:function(res){
						$('#rombel').html(res);
					}
				})
			}
		}) 
		$('#kelasbayar').on('change', function(){
			var e = $(this).val();
			if(e != ''){
				$.ajax({
					url:'tng7853y',
					type:'post',
					// dataType:'JSON',
					data:{id : e},
					success:function(res){
						$('#namasiswabayar').html(res);
					}
				})
			}
		}) 
		$('#namasiswabayar').on('change', function(){
			var e = $(this).val();
			if(e != ''){
				$.ajax({
					url:'tng4272ui',
					type:'post',
					// dataType:'JSON',
					data:{id : e},
					success:function(res){
						$('#rombelbayar').html(res);
					}
				})
			}
		}) 
		$('#namasiswabayar').on('change', function(){
			var f = $(this).val();
			if(f != ''){
				$.ajax({
					url:'tng5383hy',
					type:'post',
					// dataType:'JSON',
					data:{id : f},
					success:function(res){
						$('#jenisbiayabayar').html(res);
					}
				})
			}
		}) 
		
	</script>
</body>
</html>