<div style="padding:5px;text-align: right;">
	<button id="tgl" class="btn btn-warning" onclick="toggle();">+ Siswa</button>
</div>
<form method="post" id="tSiswa" action="<?=htmlspecialchars('simpan-siswa')?>">
	<div class="fg">
		<input type="text" name="nama" class="fc" placeholder="Nama Siswa" required>
	</div>
	<div class="fg">
		<select name="kelas" id="kelas" class="fc" required style="text-transform:uppercase;">
			<option value="0">- Kelas -</option>
			<?php
			  require_once('config/config.php');
			  $kel = "SELECT * FROM kelas WHERE parent = 0";
			  $las = $pdo->prepare($kel);
			  $las->execute();
			  $clas = $las->rowcount();
			  if($clas > 0){
			    foreach($las as $kelas){?>
			<option value="<?=$kelas['id']?>"><?=$kelas['kelas']?></option>
			      
			<?php    }
			  }
			?>
		</select>
	</div>
	<div class="fg">
	  <select name="rombel" id="rombel" class="fc" required style="text-transform:uppercase;">
	    <option value="0">- Pilih Rombel -</option>
	  </select>
	</div>
	<div class="fg">
		<input type="submit" name="simpan" class="btn btn-success" value="Simpan">
	</div>
</form>
<br>
<table>
	<thead>
		<tr>
			<td>No</td>
			<td>Nama</td>
			<td>Kelas</td>
		</tr>
	</thead>
	<tbody>
		<?php
			$no = 1; 
			require_once('config/config.php');
			$sql = "SELECT * FROM siswa";
			$tar = $pdo->prepare($sql);
			$tar->execute();
			$ct = $tar->rowcount();
			if($ct > 0){
				foreach($tar as $ik){
				$kls = $ik['kelas'];
				$cla = $pdo->prepare("SELECT * FROM kelas WHERE id = '$kls'");
				$cla->execute();
				$ccla = $cla->rowcount();
				if($ccla > 0){
				  foreach($cla as $lass){
				    $rom = $ik['rombel'];
				    $bel = $pdo->prepare("SELECT * FROM kelas WHERE id = '$rom'");
				    $bel->execute();
				    $cbel = $bel->rowcount();
				    if($cbel > 0){
				      foreach($bel as $rombel){
				?>
		<tr>
			<td><?=$no++;?></td>
			<td style="text-transform: capitalize;"><?=$ik['nama']?></td>
			<td style="text-transform: uppercase;"><?=$lass['kelas']?> <?=$rombel['kelas']?></td>
		</tr>
		<?php		} } } } }
			}
		 ?>
	</tbody>
</table>
<script type="text/javascript">
	function toggle()
	{
		var a = document.getElementById('tSiswa');
		if(a.style.display==='none'){
			a.style.display='block';

		}else{
			a.style.display='none';
		}
	}
</script>