<style type="text/css">
	.frm{
		padding:20px;
		height: 840px;
		background-color: #cbc;
		border-radius: 4px;
	}
	.box{
		flex:100%;
	}
	#fTa,#fkls{
		display: none;
	}
</style>
<div class="frm">
	<div class="row">
		<div class="box">
			<div class="row">
				<div class="box" id="fTa">
					<form method="post" action="<?=htmlspecialchars('simpan-ta')?>">
						<div class="fg">
							<input type="text" name="ta" class="fc" required placeholder="Tahun Ajaran">
						</div>
						<div class="fg">
							<input type="submit" name="simpan" class="btn btn-success" value="Simpan">
						</div>
					</form>
				</div>
				<div class="fg" style="text-align: right;">
					<button id="tta" class="btn btn-warning">+ Tahun Ajaran</button>
				</div>
				<div class="box">
					<table>
						<thead>
							<tr>
								<td>No</td>
								<td>Tahun Ajaran</td>
								<td>Status</td>
							</tr>
						</thead>
						<tbody>
							<?php 
								$no = 1;
								require_once('config/config.php');
								$sql = "SELECT * FROM ta";
								$show = $pdo->prepare($sql);
								$show->execute();
								$cs = $show->rowcount();
								if($cs > 0){
									foreach($show as $data){?>

							<tr>
								<td><?=$no++?></td>
								<td><?=$data['ta']?></td>
								<td><?php if($data['status'] == 0){echo 'Aktif';}else{echo ' Tidak Aktif';}?></td>
							</tr>
								<?php	}
								}
							 ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<br />
		<br />
		<div style="width:100%;clear:both;padding:20px;background-color:#fde;"></div>
		<br />
		<br />
		<div class="box">
		  	<div class="row">
				<div class="box" id="fkls">
					<form method="post" action="<?=htmlspecialchars('simpan-kelas')?>">
						<div class="fg">
							<input type="text" name="kelas" class="fc" required placeholder="Kelas / Rombel">
						</div>
						<div class="fg">
						  <select name="parent" id="parent" class="fc" required style="text-transform:uppercase;">
						    <option value="0">- Pilih Kelas -</option>
						    <?php
						      $no = 1;
								require_once('config/config.php');
								$sql = "SELECT * FROM kelas where parent = 0";
								$show = $pdo->prepare($sql);
								$show->execute();
								$cs = $show->rowcount();
								if($cs > 0){
									foreach($show as $data){?>
						    ?>
						    <option value="<?=$data['id']?>"><?=$data['kelas']?></option>
						    <?php } } ?>
						  </select>
						</div>
						<div class="fg">
							<input type="submit" name="simpan" class="btn btn-success" value="Simpan">
						</div>
					</form>
				</div>
				<div class="fg" style="text-align: right;">
					<button id="tkl" class="btn btn-warning">+ Kelas / Rombel</button>
				</div>
				<div class="box">
					<table>
						<thead>
							<tr>
								<td>No</td>
								<td>Kelas</td>
								<td>Rombel</td>
								<td>Status</td>
							</tr>
						</thead>
						<tbody>
							<?php 
								$no = 1;
								require_once('config/config.php');
								$sql = "SELECT * FROM kelas order by parent";
								$show = $pdo->prepare($sql);
								$show->execute();
								$cs = $show->rowcount();
								if($cs > 0){
									foreach($show as $data){?>

							<tr>
								<td><?=$no++?></td>
								<td><?=$data['kelas']?></td>
								<td><?=$data['parent']?></td>
								<td><?php if($data['status'] == 0){echo 'Aktif';}else{echo ' Tidak Aktif';}?></td>
							</tr>
								<?php	
							  } }
							 ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
