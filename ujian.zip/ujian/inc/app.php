<?php
  
  try {
    $pdo = new PDO("mysql:host=localhost;dbname=db_ujian","root","");
  } catch (PDOException $e) {
    echo $e->getmessage();
  }
  

?>