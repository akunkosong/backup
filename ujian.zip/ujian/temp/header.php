<html>
  <head>
  <meta name="keywords" content="Ujian Sekolah Online, Soa Online, Soa Ujian Online">
  <meta name="author" content="temenngoding">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>.:: Ujian Online ::.</title>
  <link rel="stylesheet" type="text/css" href="temp/mobile.css">
  </head>
  <body>
    <div class="header">
      <h2>Ujian Onlineku</h2>
      <p>
        Dibangun menggunakan <br>PHP 7 dan MySQL
      </p>
    </div>
    <div class="navbar">
      <a href="home">Home</a>
      <a href="setting">Setting</a>
      <a href="logout">Logout</a>
    </div>
    <div class="content">
      <div class="side">
        <h2 style="color:#aaa;">Penting!!</h2>
        <div class="info">
          Pastikan Sebelum mengisi ujian, kamu mendapatkan nomor ID unik (username) dari sekolah yang akan digunakan sebagai kredensial login.
        </div>
        <br>
        <div class="info">
          <form method="post" action="<?=htmlspecialchars('login')?>">
            <div class="fg">
              <input type="text" class="fc" name="username" placeholder="Username" required>
            </div>
              <div class="fg">
              <input type="password" class="fc" name="password" placeholder="Password" required>
            </div> 
            <div class="fg">
              <select name="role" class="fc" required>
                <option>- Role -</option>
                <option value="admin">Admin</option>
                <option value="guru">Guru</option>
                <option value="siswa">Siswa</option>
              </select>
            </div>
            <div class="fg">
              <input type="submit" name="login" value="Login" class="btn btn-success">
            </div>
          </form>
        </div>
      </div>
      <div class="main">

      
