<?php
  
?>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>.:: Login ::.</title>
    <style>
      body{
      }
      .timer{
        background-color:dodgerblue;
        padding:40px;
        text-align: center;
      }
      .soal{
        padding:40px;
        background-color:lightgreen;
        text-align: center;
      }
      .clear{
        clear:both;
        padding:2px;
      }
      .controller{
        display:flex;
        flex-wrap: wrap;
        background-color:gold;
        align-items: center;
        justify-content: space-between;
      }
      .left{
        flex:50%;
        text-align: left;
      }
      .right{
        flex:50%;
        text-align: right;
      }
      #next, #prev{
        border:none;
        border-radius:5px;
        padding:8px 16px;
      }
    </style>
  </head>
  <body>
    <div class="timer">
      ini header
    </div>
    <div class="controller">
      <div class="left">
        Nama Peserta <?=$_SESSION['username']?>
      </div>
      <div class="right">
        Kelas <?='XII IPA 2'?>
      </div>
    </div>
    <div class="soal">
      Berapa Jumlah 2 + x<sup>4</sup>? selesaikan dengan menggunakan metode yang sudah diajarkan!
    </div>
    <div class="clear"></div>
    <div class="controller">
      <div class="left">
        <button id="prev">Sebelumnya</button>
      </div>
      <div class="right">
        <button id="next">Selanjutnya</button>
      </div>
    </div>
  </body>
 </html.