<p style="color:#ddd;background-color:#aaa;padding:20px;">
  <strong>Web App Ujian Online Versi 1.0.0</strong> didesign khusus untuk sekolah yang ingin melaksanakan Ujian Online. <br>
  Aplikasi ini disusun menggunakan PHP Native Versi 7.3.2 dengan memanfaatkan database MySQL.
</p>