<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>.:: Login ::.</title>
    <style>
      body, html{
        height:100%;
        font-family: arial;
      }
      .wadah{
        background-image: linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.9)),url('assets/bg.jpg');
        background-size: cover;
        background-attachment: fixed;
        position: relative;
        background-position:fixed;
        background-repeat: no-repeat;
        height:100%;
      }
      .isi{
        width:300px;
        background-color:#ddd;
        top:50%;
        left:50%;
        transform: translate(-50%, -50%);
        position: absolute;
        border-radius:5px;
      }
      .fg{
        padding:10px;
      }
      input[type=text],
      input[type=submit],
      input[type=number],
      input[type=date],
      input[type=password],
      select
      {
        padding:8px 16px;
        box-sizing: border-box;
      }
      .fc{
        width:100%;
        border-radius:5px;
        border:none;
      }
      .btn{
        box-shadow: 1px 1px 1px solid #000;
        border-radius: 5px;
        border:none;
      }
      .btn-success{
        background-color:#aaa;
        color:#ddd;
      }
      .btn-block{
        width:100%;
      }
      .text-center{
        text-align: center;
      }
      .text-white{
        color:#aaa;
      }
    </style>
  </head>
  <body>
    <div class="wadah">
      <div class="isi">
        <h2 class="text-center text-white">Login</h2>
        <form action="<?=htmlspecialchars('proses-login')?>" method="post">
          <div class="fg">
            <input type="text" id="username" name="username" class="fc" placeholder="Username" required>
          </div>
          <div class="fg">
            <input type="password" id="password" name="password" class="fc" placeholder="Password" required>
          </div>
          <div class="fg">
            <input type="submit" name="login" class="btn btn-success btn-block" value="Login">
          </div>
        </form>
      </div>
    </div>
    <script>
      
    </script>
  </body>
</html>