<?php
  session_start();
  if(!isset($_SESSION['username'])){
    header('location: login');
  }
  ?>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>.:: Dashboard Admin ::.</title>
    <link rel="stylesheet" href="../temp/mobile.css">
  </head>
  <body>
    <div class="header">
      <h2>Welcome back <?=$_SESSION['username']?></h2>
      <p>Kelola semua data dengan benar ya!</p>
    </div>
    <div class="navbar">
      <a href="kelola-guru">Kelola Guru</a>
      <a href="">Kelola Siswa</a>
      <a href="">Kelola Kelas</a>
      <a href="">Kelola Mapel</a>
      <a href="">Kelola Nilai</a>
    </div>
    <div class="row">
      <div class="side">
        <p style="color:#aaa">
          Segera Lakukan pembaharuan akun anda
        </p>
      </div>
      <div class="main">
        <p style="padding:0 6px;color:#aaa">
        Semua Data yang tertera disini, wajib dikelola oleh admin, karena yang lain tidak dapat mengakses halaman ini
      </p>
      </div>
    </div>
    <div class="footer">
      &copy; copyright <?=date('Y') ?>  <a href="http://temenngoding.com">www.temenngoding.com</a>
    </div>
  </body>
</html>