<?php

  require_once("../inc/app.php");
  if(!empty($_POST['login'])){
    $a = htmlspecialchars(strtolower($_POST['username']));
    $b = $_POST['password'];
    try {
      $login = $pdo->prepare("SELECT * FROM users WHERE username = ?");
      $login->bindparam(1, $a, PDO::PARAM_STR);
      $login->execute();
      $clo = $login->rowcount();
      if($clo > 0){
        foreach($login as $user){
          if($user['password']==$b){
          session_start();
          $_SESSION['username'] = $user['username'];
          $_SESSION['status'] = $user['status'];
          echo "<script>alert('Selamat Datang, Anda sudah dapat memulai Ujian');location.href='mulai';</script>";
          }else{
          echo "<script>alert('Aduh, password kamu salah');location.href='login';</script>";
        }
        }
     }else{
          echo "<script>alert('Aduh, username kamu salah');location.href='login';</script>";
     }
    } catch (PDOException $e) {
      echo $e->getmessage();
    }
  }