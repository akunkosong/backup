<?php
  
  session_start();
  session_unset();
  session_destroy();
  echo "<script>alert('Anda sudah keluar dari sistem');location.href='login';</script>";


?>