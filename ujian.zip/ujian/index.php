<?php
  session_start();
  if(!isset($_SESSION['username'])){
    echo "<script>alert('Login dulu yuk!');location.href='login';</script>";
  }
  require_once('temp/header.php');
  
  $page = (isset($_GET['page']))?$_GET['page']:'home';
  switch ($page) {
    case 'home':include'pages/overview.php';break;
    case 'setting':include'pages/setting.php';break;

    
    default:include'pages/overview.php';break;
  }

  require_once('temp/footer.php');

?>