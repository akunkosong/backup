<?php

namespace Google\Site_Kit_Dependencies\Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{
}
